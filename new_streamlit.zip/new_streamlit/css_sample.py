from PIL import Image
import streamlit as st

# You can always call this function where ever you want

def add_logo(logo_path, width, height):
    """Read and return a resized logo"""
    logo = Image.open(logo_path)
    modified_logo = logo.resize((width, height))
    return modified_logo

# my_logo = add_logo(logo_path="C:/Users/ajay/Downloads/R.png", width=200, height=60)
# st.sidebar.image(my_logo)

# OR

# st.sidebar.image(add_logo(logo_path="C:/Users/ajay/Downloads/R.png", width=100, height=60)) 