import streamlit as st
from database import create_connection, fetch_data_from_mysql, insert_data_into_mysql  # Import database functions
import hashlib
import os
import smtplib
from mysql.connector import Error  # Import Error from mysql.connector
from datetime import datetime, timedelta
import dashboard3
from css_sample import add_logo
import logging
import re
# from dotenv import load_dotenv
import random
import string
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import time

# Load environment variables
# load_dotenv()
#
# smtp_server = os.getenv('SMTP_SERVER')
# smtp_port = int(os.getenv('SMTP_PORT'))
# smtp_user = os.getenv('SMTP_USER')
# smtp_password = os.getenv('SMTP_PASSWORD')

# Configure logging
logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s %(message)s')

def clear_form_signup():
    st.session_state["email_sp"] = ""
    st.session_state["signup_password"] = ""
    st.session_state["signup_confirm_password"] = ""
    st.session_state["associate_name"] = ""

# Function to check if the email is an Outlook email
def is_outlook_email(email):
    return re.match(r'^[a-zA-Z0-9_.+-]+@outlook\.com$', email) is not None

# Function to validate email format
def is_valid_email(email):
    return re.match(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$', email) is not None

# Hashing password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Sign Up function
def sign_up(user_email, password, confirm_password, associate_name, role='user'):
    if not is_valid_email(user_email):
        st.error("Please enter a valid email address.")
        return

    if not is_outlook_email(user_email):
        st.error("Only Outlook email addresses are allowed.")
        return

    if not password or not confirm_password:
        st.error("Both password fields are required.")
        return

    if password != confirm_password:
        st.error("Passwords do not match.")
        return

    if len(password) < 8:
        st.error("Password must be at least 8 characters long.")
        return

    if not associate_name:
        st.error("Associate Name is required.")
        return

    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        hashed_password = hash_password(password)
        try:
            cursor.execute("INSERT INTO users (user_email, password, associate_name, role) VALUES (%s, %s, %s, %s)", (user_email, hashed_password, associate_name, role))
            connection.commit()
            st.success("User registered successfully!")
            logging.info(f"User registered: {user_email}")
        except Error as e:
            st.error(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()

# Sign In function
def sign_in(user_email, password):
    if not is_valid_email(user_email):
        st.error("Please enter a valid email address.")
        return

    if not password:
        st.error("Password field is required.")
        return

    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        hashed_password = hash_password(password)
        try:
            cursor.execute("SELECT * FROM users WHERE user_email = %s AND password = %s", (user_email, hashed_password))
            user = cursor.fetchone()
            if user:
                st.session_state['logged_in'] = True
                st.session_state['username'] = user[1]  # Assuming user_email is at index 1
                st.session_state['role'] = user[4]  # Assuming role is at index 4
                st.session_state['user_info'] = {
                    'associate_name': user[3],  # Assuming associate_name is at index 2
                    'email_id': user[1]  # Assuming user_email is at index 1
                }
                st.success("Logged in successfully!")
                logging.info(f"User logged in: {user_email}")
                st.experimental_rerun()  # Trigger rerun after login
            else:
                st.error("Invalid user email or password")
        except Error as e:
            st.error(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()

# Log Out function
def log_out():
    st.session_state['logged_in'] = False
    st.session_state['username'] = ''
    st.session_state['role'] = ''
    st.session_state['user_info'] = None
    logging.info(f"User logged out: {st.session_state['username']}")
    st.experimental_rerun()  # Trigger rerun after logout

# Token Generator
# def generate_token():
#     return ''.join(random.choices(string.ascii_letters + string.digits, k=10))

# Send Token Mail
# def send_reset_email(email, token):
#     reset_link = f"{token}"
#     msg = MIMEMultipart()
#     msg['From'] = smtp_user
#     msg['To'] = email
#     msg['Subject'] = 'Password Reset Request'
#
#     body = f"""
#     <html>
#     <body>
#         <h2>Password Reset Request</h2>
#         <p>Dear User,</p>
#         <p>We received a request to reset your password for your account associated with this email address. Please check temporary token number below to reset your password:</p>
#         <p><a href="{reset_link}">{reset_link}</a></p>
#         <p>If you did not request a password reset, please ignore this email or contact support if you have any questions.</p>
#         <p>This link will expire in 1 hour.</p>
#         <br>
#         <p>Thank you,</p>
#         <p>Fujitsu</p>
#     </body>
#     </html>
#     """
#     msg.attach(MIMEText(body, 'html'))
#
#     try:
#         server = smtplib.SMTP(smtp_server, smtp_port)
#         server.starttls()
#         server.login(smtp_user, smtp_password)
#         text = msg.as_string()
#         server.sendmail(smtp_user, email, text)
#         server.quit()
#         st.success("A password reset email has been sent.")
#     except Exception as e:
#         st.error(f"Error: {e}")

# def request_password_reset(email):
#     if not is_valid_email(email):
#         st.error("Please enter a valid email address.")
#         return
#
#     connection = create_connection()
#     if connection:
#         cursor = connection.cursor()
#         try:
#             token = generate_token()
#             expiration = datetime.now() + timedelta(hours=1)  # Token valid for 1 hour
#             cursor.execute("INSERT INTO password_resets (email, token, expiration) VALUES (%s, %s, %s)", (email, token, expiration))
#             connection.commit()
#             send_reset_email(email, token)
#             st.session_state['reset_email_sent'] = True
#             st.session_state['reset_email'] = email
#         except Error as e:
#             st.error(f"Error: {e}")
#         finally:
#             cursor.close()
#             connection.close()
#
# def reset_password(token, new_password):
#     if not new_password:
#         st.error("New password field is required.")
#         return
#
#     connection = create_connection()
#     if connection:
#         cursor = connection.cursor()
#         try:
#             cursor.execute("SELECT email, expiration FROM password_resets WHERE token = %s", (token,))
#             result = cursor.fetchone()
#             if result:
#                 email, expiration = result
#                 if datetime.now() > expiration:
#                     st.error("This token has expired.")
#                 else:
#                     hashed_password = hash_password(new_password)
#                     cursor.execute("UPDATE users SET password = %s WHERE user_email = %s", (hashed_password, email))
#                     cursor.execute("DELETE FROM password_resets WHERE token = %s", (token,))
#                     connection.commit()
#                     st.success("Your password has been reset successfully.")
#                     st.session_state['reset_email_sent'] = False
#                     st.session_state.page = 'Login'
#                     st.session_state['reset_token'] = ''
#                     st.session_state['reset_new_password'] = ''
#                     st.session_state['reset_confirm_password'] = ''
#                     st.session_state['reset_email'] = ''
#                     st.experimental_rerun()  # Trigger rerun to switch to login tab
#             else:
#                 st.error("Invalid token.")
#         except Error as e:
#             st.error(f"Error: {e}")
#         finally:
#             cursor.close()
#             connection.close()

# Streamlit app

if 'logged_in' not in st.session_state:
    st.session_state['logged_in'] = False
    st.session_state['username'] = ''
    st.session_state['role'] = ''
    st.session_state['user_info'] = None

if st.session_state['logged_in']:
    if st.session_state['role'] == 'admin':
        dashboard3.display_admin_panel()
    else:
        user_email = st.session_state['user_info']['email_id']
        user_data = fetch_data_from_mysql(user_email)  # Fetch user-specific data
        dashboard3.display_dashboard(st.session_state['user_info'], st.session_state['role'], user_data)
else:
    if 'page' not in st.session_state:
        st.session_state.page = 'Home'
    st.sidebar.image(add_logo(logo_path="R.png", width=180, height=100))
    tab1, tab2, tab3, tab4 = st.tabs(["Home", "Login", "Sign Up", "Reset Password"])

    with tab1:
        st.header(":red[Welcome to GAPF Resources!!]")

    with tab2:
        st.subheader("Login Section")
        user_email = st.text_input("Email")
        password = st.text_input("Password", type='password')

        if st.button("Login"):
            sign_in(user_email, password)

    with tab3:
        st.subheader("Create New Account")
        user_email = st.text_input("New Email")
        password = st.text_input("New Password", key='signup_password')
        confirm_password = st.text_input("Confirm Password", key='signup_confirm_password')
        associate_name = st.text_input("Enter Associate Name (First name, Last name)", key='associate_name')
        if st.button("Sign Up"):
            sign_up(user_email, password, confirm_password, associate_name, role='user')
            # time.sleep(3)
    
    with tab4:
        st.header("Reset Your Password")
        reset_email = st.text_input("Enter Email Id")
        sent_mail_button = st.button("Send Token")
        if sent_mail_button:
            # request_password_reset(reset_email)
            pass
        # if st.session_state.get('reset_email_sent', False):
        #     token = st.text_input('Token', value=st.session_state.get('reset_token', ''))
        #     new_password = st.text_input('New Password', type='password', value=st.session_state.get('reset_new_password', ''))
        #     confirm_password = st.text_input('Confirm Password', type='password', value=st.session_state.get('reset_confirm_password', ''))
        #     reset_button = st.button('Reset Password', key='reset_password_button_reset')
        #     if reset_button:
        #         if new_password != confirm_password:
        #             st.error("Passwords do not match.")
        #         else:
        #             st.session_state['reset_token'] = token
        #             st.session_state['reset_new_password'] = new_password
        #             st.session_state['reset_confirm_password'] = confirm_password
        #             reset_password(token, new_password)
