import streamlit as st
from datetime import datetime
import mysql.connector
from mysql.connector import Error

# Function to display the success message
def show_success_message(msg):
    st.sidebar.success(msg)

# Function to remove the success message
def remove_success_message():
    st.markdown('<script>setTimeout(function() { const success = document.getElementsByClassName("stAlert")[0]; success.style.display = "none"; }, 3000);</script>', unsafe_allow_html=True)


# MySQL Database connection
def create_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='reporting_automation',
            user='root',
            password='root'
        )
        return connection
    except Error as e:
        print(f"Error: '{e}'")
        return None

# Fetch data from MySQL based on user_email
def fetch_data_from_mysql(user_email):
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT associate_name, email_id, project, allocation_percent, date, weekly_data, ticket_ref_number FROM user_data WHERE email_id = %s", (user_email,))
            result = cursor.fetchall()
            return result
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()
    return []

# Fetch data from MySQL for admin
def fetch_admin_data_from_mysql():
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT associate_name, email_id, project, allocation_percent, date, weekly_data, ticket_ref_number FROM user_data")
            result = cursor.fetchall()
            return result
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()
    return []

# Insert data into MySQL
def insert_data_into_mysql(associate_name, email_id, project, allocation_percent, date, weekly_data, ticket_ref_number):
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        try:
            # Check if the data already exists in the database for the given email and combination of other fields
            query = """
            SELECT * FROM user_data 
            WHERE email_id = %s 
            AND associate_name = %s  
            AND ticket_ref_number = %s
            """
            cursor.execute(query, (
                email_id, associate_name, ticket_ref_number
            ))
            result = cursor.fetchone()
            
            if result:
                print("Duplicate data for this email and combination of fields already exists.")
                # st.sidebar.error("Duplicate data for this email and combination of fields already exists.")
                show_success_message("Duplicate data for this email and combination of fields already exists.")
                remove_success_message()
            else:
                # Insert the unique data into the database
                insert_query = """
                INSERT INTO user_data (associate_name, email_id, project, allocation_percent, date, weekly_data, ticket_ref_number) 
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(insert_query, (
                    associate_name, email_id, project, allocation_percent, 
                    date, weekly_data, ticket_ref_number
                ))
                connection.commit()
                print("Data has been successfully added.")
                show_success_message("Data has been successfully added.")
                remove_success_message()
                # st.sidebar.success("Data has been successfully added.")
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()