from datetime import datetime
import mysql.connector
from mysql.connector import Error

# MySQL Database connection
def create_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='reporting_automation',
            user='root',
            password='root'
        )
        return connection
    except Error as e:
        print(f"Error: '{e}'")
        return None

# Fetch data from MySQL based on user_email
def fetch_data_from_mysql(user_email):
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT associate_name, email_id, project, allocation_percent, date, weekly_data, ticket_ref_number FROM user_data WHERE email_id = %s", (user_email,))
            result = cursor.fetchall()
            return result
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()
    return []

# Fetch data from MySQL for admin
def fetch_admin_data_from_mysql():
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT associate_name, email_id, project, allocation_percent, date, weekly_data, ticket_ref_number FROM user_data")
            result = cursor.fetchall()
            return result
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()
    return []

# Insert data into MySQL
def insert_data_into_mysql(associate_name, email_id, project, allocation_percent, date, weekly_data, ticket_ref_number):
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("""
                INSERT INTO user_data (associate_name, email_id, project, allocation_percent, date, weekly_data, ticket_ref_number) 
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (
                associate_name, email_id, project, allocation_percent, 
                date, weekly_data, ticket_ref_number
            ))
            connection.commit()
        except Error as e:
            print(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()
