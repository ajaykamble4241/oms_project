import streamlit as st
from streamlit_option_menu import option_menu
import os
from dotenv import load_dotenv
import login, signup, forgot_password
load_dotenv()

st.set_page_config(
        page_title="Pondering",
)

st.markdown(
    """
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src=f"https://www.googletagmanager.com/gtag/js?id={os.getenv('analytics_tag')}"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', os.getenv('analytics_tag'));
        </script>
    """, unsafe_allow_html=True)
print(os.getenv('analytics_tag'))

class MultiApp:

    def __init__(self):
        self.apps = []

    def add_app(self, title, func):

        self.apps.append({
            "title": title,
            "function": func
        })

    def run(self):
        if "current_page" not in st.session_state:
            st.session_state["current_page"] = "Home"

        with st.sidebar:
            app = option_menu(
                menu_title='GAPF Resources Tool',
                options=['Home','Account','about'],
                icons=['house-fill','person-circle','person-plus','lock','info-circle-fill'],
                # menu_icon='chat-text-fill',
                default_index=1,
                styles={
                    "container": {"padding": "5!important","background-color":'#f2003c'},
        "icon": {"color": "white", "font-size": "20px"}, 
        "nav-link": {"color":"white","font-size": "18px", "text-align": "left", "margin":"0px", "--hover-color": "#3792cb"},
        "nav-link-selected": {"background-color": "#363636"},}
            )

            if app == "Home":
                st.header(":red[Welcome to GAPF Resources!!]")
            if app != "Home":
                st.session_state["current_page"] = app

        self.apps_func[st.session_state["current_page"]]()

    apps_func = {
        "Home": lambda: None,
        "Account": login.main,
        "about": lambda: None,
    }

if __name__ == "__main__":
    app = MultiApp()
    app.run()