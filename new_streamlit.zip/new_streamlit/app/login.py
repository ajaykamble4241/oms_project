import streamlit as st
import hashlib
import logging
import mysql.connector
from mysql.connector import Error 
import dashboard3
from database import create_connection, fetch_data_from_mysql, insert_data_into_mysql

# Create a connection to the database
def create_connection():
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="reporting_automation"
    )
    return connection

# Hashing the password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Sign In function
def sign_in(user_email, password):
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        hashed_password = hash_password(password)
        try:
            cursor.execute("SELECT * FROM users WHERE user_email = %s AND password = %s", (user_email, hashed_password))
            user = cursor.fetchone()
            if user:
                st.session_state['logged_in'] = True
                st.session_state['username'] = user[1]  # Assuming user_email is at index 1
                st.session_state['role'] = user[4]  # Assuming role is at index 4
                st.session_state['user_info'] = {
                    'associate_name': user[3],  # Assuming associate_name is at index 2
                    'email_id': user[1]  # Assuming user_email is at index 1
                }
                st.success("Logged in successfully!")
                logging.info(f"User logged in: {user_email}")
                st.experimental_rerun()  # Trigger rerun after login
            else:
                st.error("Invalid user email or password")
        except Error as e:
            st.error(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()


# Main function
def main():
    st.title("Login Section")

    if 'logged_in' not in st.session_state:
        st.session_state['logged_in'] = False
        st.session_state['username'] = ''
        st.session_state['role'] = ''
        st.session_state['user_info'] = None

    if st.session_state['logged_in']:
        if st.session_state['role'] == 'admin':
            dashboard3.display_admin_panel()
        else:
            user_email = st.session_state['user_info']['email_id']
            user_data = fetch_data_from_mysql(user_email)  # Fetch user-specific data
            dashboard3.display_dashboard(st.session_state['user_info'], st.session_state['role'], user_data)
    else:
        st.subheader("Login")
        user_email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        if st.button("Login"):
            sign_in(user_email, password)


if __name__ == "__main__":
    main()
   