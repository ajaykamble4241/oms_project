import streamlit as st
import hashlib
import logging
import mysql.connector
from mysql.connector import Error 
import dashboard3

# Create a connection to the database
def create_connection():
    connection = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="reporting_automation"
    )
    return connection

# Hashing the password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Register function
def register(associate_name, email_id, password, role):
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        try:
            hashed_password = hash_password(password)
            cursor.execute("INSERT INTO users (associate_name, user_email, password, role) VALUES (%s, %s, %s, %s)", 
                           (associate_name, email_id, hashed_password, role))
            connection.commit()
            st.success("User created successfully!")
            logging.info(f"User created: {email_id}")
        except mysql.connector.Error as e:
            st.error(f"Error: '{e}'")
        finally:
            cursor.close()
            connection.close()

# Main function
def main():
    st.title("Register User")

    if 'logged_in' not in st.session_state:
        st.session_state['logged_in'] = False
        st.session_state['username'] = ''
        st.session_state['role'] = ''
        st.session_state['user_info'] = None

    if st.session_state['logged_in']:
        if st.session_state['role'] == 'admin':
            dashboard3.display_admin_panel()
        else:
            user_email = st.session_state['user_info']['email_id']
            user_data = fetch_data_from_mysql(user_email)  # Fetch user-specific data
            dashboard3.display_dashboard(st.session_state['user_info'], st.session_state['role'], user_data)
    else:
        st.subheader("Register")
        associate_name = st.text_input("Associate Name")
        email_id = st.text_input("Email")
        password = st.text_input("Password", type="password")
        if st.button("Register"):
            register(associate_name, email_id, password, 'user')

if __name__ == "__main__":
    main()
   