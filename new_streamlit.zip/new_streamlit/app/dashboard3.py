import streamlit as st
import pandas as pd
import plotly.express as px
from database import fetch_admin_data_from_mysql, fetch_data_from_mysql, insert_data_into_mysql
from css_sample import add_logo

# Log actions for aggregation and data insertion
import logging
logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s %(message)s')

def log_out():
    st.session_state['logged_in'] = False
    st.session_state['username'] = ''
    st.session_state['role'] = ''
    st.session_state['user_info'] = None
    logging.info(f"User logged out: {st.session_state['username']}")
    st.experimental_rerun()  # Trigger rerun after logout

def display_dashboard(user_info, role, data):
    st.title(f"Welcome {user_info['associate_name']}")
    st.write("Here is your data:")
    st.sidebar.image(add_logo(logo_path="R.png", width=100, height=60))

    # Display user-specific data
    if data:
        df = pd.DataFrame(data, columns=['Associate Name', 'Email ID', 'Project', 'Allocation (%)', 'Date', 'Weekly_Data', 'Ticket Reference Number'])
        st.write(df)
        logging.info(f"Displayed data for user: {user_info['email_id']}")
        columns = ['Associate Name', 'Email ID', 'Project', 'Allocation (%)', 'Date', 'Weekly_Data', 'Ticket Reference Number']
        df = pd.DataFrame(data, columns=columns[:len(data[0])])
        # Sidebar inputs for date range
        st.header("Date Range for Mothly Data")
        start_date_mysql = st.date_input('Start date Mothly Data', df['Date'].min().date())
        end_date_mysql = st.date_input('End date Mothly Data', df['Date'].max().date())

        start_date_mysql = pd.to_datetime(start_date_mysql)
        end_date_mysql = pd.to_datetime(end_date_mysql)

        mask_mysql = (df['Date'] >= start_date_mysql) & (df['Date'] <= end_date_mysql)
        filtered_df_mysql = df.loc[mask_mysql].copy()
        if not filtered_df_mysql.empty:
            filtered_df_mysql.set_index('Date', inplace=True)
            # Perform aggregation on weekly_data column
            agg_df = df.groupby(['Associate Name', 'Email ID', 'Project', 'Allocation (%)']).agg({
                'Weekly_Data': 'sum'
            }).reset_index()
            st.write("Aggregated Data:")
            st.write(agg_df)
            logging.info(f"Aggregated data displayed for user: {user_info['email_id']}")

            fig = px.bar(agg_df, x='Project', y='Weekly_Data', color='Project', title="Weekly Data by Associate and Project")
            st.plotly_chart(fig)
            logging.info(f"{user_info['email_id']} charts displayed")
    else:
        st.write("No data available.")
        logging.info(f"No data found for user: {user_info['email_id']}")

    st.sidebar.header("Admin Input Data")
    input_name = user_info['associate_name']
    input_email = user_info['email_id']
    st.sidebar.text_input("Associate Name (First, Last)", input_name, disabled=True)
    st.sidebar.text_input("Email ID", input_email, disabled=True)

    project = st.sidebar.text_input("Project")
    allocation = st.sidebar.number_input("Allocation (%)", min_value=0, max_value=100, step=1)
    date = st.sidebar.date_input("Date")
    weekly_data = st.sidebar.number_input("Weekly Data", min_value=0)
    ticket_reference_number = st.sidebar.text_input("Ticket Reference Number")

    if st.sidebar.button("Submit Admin Data"):
        # Insert data into MySQL
        insert_data_into_mysql(input_name, input_email, project, allocation, date, weekly_data, ticket_reference_number)
        st.sidebar.success("Admin data submitted successfully!")
        logging.info(f"Admin data submitted for: {input_email}")
        st.experimental_rerun()  

def display_admin_panel():
    st.title("Admin Dashboard")
    st.button('logout')
    st.write("All Users data:")
    st.sidebar.image(add_logo(logo_path="R.png", width=100, height=60))
    
    admin_data = fetch_admin_data_from_mysql()
    

    
    if admin_data:
        df = pd.DataFrame(admin_data, columns=['Associate Name', 'Email ID', 'Project', 'Allocation (%)', 'Date', 'Weekly_Data', 'Ticket Reference Number'])
        st.write(df)
        logging.info("Displayed data for admin")
        columns = ['Associate Name', 'Email ID', 'Project', 'Allocation (%)', 'Date', 'Weekly_Data', 'Ticket Reference Number']
        df = pd.DataFrame(admin_data, columns=columns[:len(admin_data[0])])
        # Sidebar inputs for date range
        st.header("Date Range for Mothly Data")
        start_date_mysql = st.date_input('Start date Mothly Data', df['Date'].min().date())
        end_date_mysql = st.date_input('End date Mothly Data', df['Date'].max().date())

        start_date_mysql = pd.to_datetime(start_date_mysql)
        end_date_mysql = pd.to_datetime(end_date_mysql)

        mask_mysql = (df['Date'] >= start_date_mysql) & (df['Date'] <= end_date_mysql)
        filtered_df_mysql = df.loc[mask_mysql].copy()
        if not filtered_df_mysql.empty:
            filtered_df_mysql.set_index('Date', inplace=True)

            # Resample and aggregate the data
            agg_df = filtered_df_mysql.groupby(['Associate Name', 'Email ID', 'Project', 'Allocation (%)']).agg({
            'Weekly_Data': 'sum'
            }).reset_index()
            st.write("Aggregated Data:")
            st.write(agg_df)
            logging.info("Aggregated data displayed for admin")
            fig = px.bar(agg_df, x='Associate Name', y='Weekly_Data', color='Project', title="Weekly Data by Associate and Project")
            st.plotly_chart(fig)
            logging.info("Admin dashboard charts displayed")

    else:
        st.write("No data available.")
        logging.info("No data found for admin")

    # Admin input fields
    st.sidebar.header("Admin Input Data")
    associate_name = st.sidebar.text_input("Associate Name")
    email_id = st.sidebar.text_input("Email ID")
    project = st.sidebar.text_input("Project")
    allocation = st.sidebar.number_input("Allocation (%)", min_value=0, max_value=100, step=1)
    date = st.sidebar.date_input("Date")
    weekly_data = st.sidebar.number_input("Weekly Data", min_value=0)
    ticket_reference_number = st.sidebar.text_input("Ticket Reference Number")

    if st.sidebar.button("Submit Admin Data"):
        # Insert data into MySQL
        insert_data_into_mysql(associate_name, email_id, project, allocation, date, weekly_data, ticket_reference_number)
        st.sidebar.success("Admin data submitted successfully!")
        logging.info(f"Admin data submitted for: {email_id}")
        st.experimental_rerun()  

def main():
    # Fetch the query parameters
    query_params = st.experimental_get_query_params()
    user_info = {
        'associate_name': query_params.get('user', [''])[0],
        'email_id': query_params.get('email', [''])[0]
    }
    role = query_params.get('role', [''])[0]

    if role == 'admin':
        display_admin_panel()
    else:
        # User input fields
        st.sidebar.header("Input your data")
        user_info['associate_name'] = st.sidebar.text_input("Associate Name", user_info['associate_name'])
        user_info['email_id'] = st.sidebar.text_input("Email ID", user_info['email_id'])
        project = st.sidebar.text_input("Project")
        allocation = st.sidebar.number_input("Allocation (%)", min_value=0, max_value=100, step=1)
        date = st.sidebar.date_input("Date")
        weekly_data = st.sidebar.number_input("Weekly Data", min_value=0)
        ticket_reference_number = st.sidebar.text_input("Ticket Reference Number")

        if st.sidebar.button("Submit"):
            # Insert data into MySQL
            insert_data_into_mysql(user_info['associate_name'], user_info['email_id'], project, allocation, date, weekly_data, ticket_reference_number)
            st.sidebar.success("Data submitted successfully!")
            logging.info(f"Data submitted by user: {user_info['email_id']}")
            st.experimental_rerun()  

        # Fetch data for the specific user
        data = fetch_data_from_mysql(user_info['email_id'])
        display_dashboard(user_info, role, data)

if __name__ == '__main__':
    main()
