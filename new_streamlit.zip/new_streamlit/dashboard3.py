import streamlit as st
import pandas as pd
import plotly.express as px
from database import fetch_admin_data_from_mysql, fetch_data_from_mysql, insert_data_into_mysql
from css_sample import add_logo
import logging
import re
import time

# Configure logging
logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s %(message)s')

def clear_form_user():
    st.session_state["project"] = ""
    st.session_state["allocation"] = 0
    st.session_state["weekly_data"] = 0
    st.session_state["ticket_reference_number"] = ""

def clear_form_admin():
    st.session_state["email"] = ""
    st.session_state["associate_name"] = ""
    st.session_state["project"] = ""
    st.session_state["allocation"] = 0
    st.session_state["weekly_data"] = 0
    st.session_state["ticket_reference_number"] = ""

# Helper functions for validation
def is_valid_email(email):
    return re.match(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$', email) is not None

def is_outlook_email(email):
    return re.match(r'^[a-zA-Z0-9_.+-]+@outlook\.com$', email) is not None

def validate_inputs(associate_name, email, project, allocation, date, weekly_data, ticket_reference_number):
    if not associate_name:
        return "Associate Name is required."
    if not is_valid_email(email):
        return "Invalid email format."
    if not is_outlook_email(email):
        return "Only Outlook email addresses are allowed."
    if not project:
        return "Project is required."
    if not (0 <= allocation <= 100):
        return "Allocation (%) must be between 0 and 100."
    if weekly_data < 0:
        return "Weekly Data must be a non-negative number."
    if not ticket_reference_number:
        return "Ticket Reference Number is required."
    return None

def logout():
    st.session_state['logged_in'] = False
    st.rerun()

def display_dashboard(user_info, role, data):
    col1, col2 = st.columns([0.8, 0.2])
    with col1:
        st.title(f"Welcome {user_info['associate_name']}")
    with col2:
        if st.button("Logout"):
            logout()

    st.write("Here is your data:")
    st.sidebar.image(add_logo(logo_path="R.png", width=100, height=60))

    # Display user-specific data
    if data:
        df = pd.DataFrame(data, columns=['Associate Name', 'Email ID', 'Project', 'Allocation (%)', 'Date', 'Weekly_Data', 'Ticket Reference Number'])
        st.write(df)
        logging.info(f"Displayed data for user: {user_info['email_id']}")
        columns = ['Associate Name', 'Email ID', 'Project', 'Allocation (%)', 'Date', 'Weekly_Data', 'Ticket Reference Number']
        df = pd.DataFrame(data, columns=columns[:len(data[0])])
        # Sidebar inputs for date range
        st.header("Date Range for Monthly Data")
        start_date_mysql = st.date_input('Start date Monthly Data', df['Date'].min().date())
        end_date_mysql = st.date_input('End date Monthly Data', df['Date'].max().date())

        start_date_mysql = pd.to_datetime(start_date_mysql)
        end_date_mysql = pd.to_datetime(end_date_mysql)
        if st.button("submit"):
            mask_mysql = (df['Date'] >= start_date_mysql) & (df['Date'] <= end_date_mysql)
            filtered_df_mysql = df.loc[mask_mysql].copy()
            
            if not filtered_df_mysql.empty:
                filtered_df_mysql.set_index('Date', inplace=True)
                # Perform aggregation on weekly_data column
                agg_df = filtered_df_mysql.groupby(['Associate Name', 'Email ID', 'Project', 'Allocation (%)']).agg({
                    'Weekly_Data': 'sum'
                }).reset_index()
                agg_df=agg_df.rename(columns = {'Weekly_Data':'Monthly Data'})
                st.write("Aggregated Data:")
                st.write(agg_df)
                logging.info(f"Aggregated data displayed for user: {user_info['email_id']}")
                # st.experimental_rerun()
                fig = px.bar(agg_df, x='Project', y='Monthly Data', color='Project', title="Weekly Data by Associate and Project")
                st.plotly_chart(fig)
                logging.info(f"{user_info['email_id']} charts displayed")
        

    else:
        st.write("No data available.")
        logging.info(f"No data found for user: {user_info['email_id']}")

    st.sidebar.header("Admin Input Data")
    input_name = user_info['associate_name']
    input_email = user_info['email_id']
    st.sidebar.text_input("Associate Name (First, Last)", input_name, key='associate_name' , disabled=True)
    st.sidebar.text_input("Email ID", input_email, key='email', disabled=True)
    project = st.sidebar.text_input("Project", key='project')
    allocation = st.sidebar.number_input("Allocation (%)", key='allocation', min_value=0, max_value=100, step=1)
    date = st.sidebar.date_input("Date", value=st.session_state.get('date', pd.Timestamp.now()))
    weekly_data = st.sidebar.number_input("Weekly Data", key='weekly_data', min_value=0)
    ticket_reference_number = st.sidebar.text_input("Ticket Reference Number", key='ticket_reference_number')

    if st.sidebar.button("Submit Admin Data"):
        error_msg = validate_inputs(input_name, input_email, project, allocation, date, weekly_data, ticket_reference_number)
        if error_msg:
            st.sidebar.error(error_msg)
        else:
            # Insert data into MySQL
            insert_data_into_mysql(input_name, input_email, project, allocation, date, weekly_data, ticket_reference_number)
            # st.sidebar.success("data submitted successfully!")
            logging.info(f"data submitted for: {input_email}")
            st.experimental_rerun()

    if st.sidebar.button("Reset Inputs", on_click=clear_form_user):   
         st.sidebar.success("All inputs are resets")   
                
def display_admin_panel():
    col1, col2 = st.columns([0.8, 0.2])
    with col1:
        st.title("Admin Dashboard")
    with col2:
        if st.button("Logout"):
            logout()

    st.write("All Users data:")
   
    st.sidebar.image(add_logo(logo_path="R.png", width=100, height=60))
    
    admin_data = fetch_admin_data_from_mysql()
    
    if admin_data:
        df = pd.DataFrame(admin_data, columns=['Associate Name', 'Email ID', 'Project', 'Allocation (%)', 'Date', 'Weekly_Data', 'Ticket Reference Number'])
        st.write(df)
        logging.info("Displayed data for admin")
        columns = ['Associate Name', 'Email ID', 'Project', 'Allocation (%)', 'Date', 'Weekly_Data', 'Ticket Reference Number']
        df = pd.DataFrame(admin_data, columns=columns[:len(admin_data[0])])
        # Sidebar inputs for date range
        st.header("Date Range for Monthly Data")
        start_date_mysql = st.date_input('Start date Monthly Data', df['Date'].min().date())
        end_date_mysql = st.date_input('End date Monthly Data', df['Date'].max().date())

        start_date_mysql = pd.to_datetime(start_date_mysql)
        end_date_mysql = pd.to_datetime(end_date_mysql)
        if st.button("submit"):
            mask_mysql = (df['Date'] >= start_date_mysql) & (df['Date'] <= end_date_mysql)
            filtered_df_mysql = df.loc[mask_mysql].copy()
            if not filtered_df_mysql.empty:
                filtered_df_mysql.set_index('Date', inplace=True)

                # Resample and aggregate the data
                agg_df = filtered_df_mysql.groupby(['Associate Name', 'Email ID', 'Project', 'Allocation (%)']).agg({
                    'Weekly_Data': 'sum'
                }).reset_index()
                agg_df=agg_df.rename(columns = {'Weekly_Data':'Monthly Data'})
                st.write("Aggregated Data:")
                st.write(agg_df)
                logging.info("Aggregated data displayed for admin")
                fig = px.bar(agg_df, x='Associate Name', y='Monthly Data', color='Project', title="Monthly Data by Associate and Project")
                st.plotly_chart(fig)
                logging.info("Admin dashboard charts displayed")

    else:
        st.write("No data available.")
        logging.info("No data found for admin")

    # Admin input fields
    st.sidebar.header("Admin Input Data")
    associate_name = st.sidebar.text_input("Associate Name", key='associate_name')
    email_id = st.sidebar.text_input("Email ID", key='email')
    project = st.sidebar.text_input("Project", key='project')
    allocation = st.sidebar.number_input("Allocation (%)", min_value=0, max_value=100, step=1, key='allocation')
    date = st.sidebar.date_input("Date", value=st.session_state.get('date', pd.Timestamp.now()))
    weekly_data = st.sidebar.number_input("Weekly Data", min_value=0, key='weekly_data')
    ticket_reference_number = st.sidebar.text_input("Ticket Reference Number", key='ticket_reference_number')

    if st.sidebar.button("Submit Admin Data"):
        error_msg = validate_inputs(associate_name, email_id, project, allocation, date, weekly_data, ticket_reference_number)
        if error_msg:
            st.sidebar.error(error_msg)
        else:
            # Insert data into MySQL
            insert_data_into_mysql(associate_name, email_id, project, allocation, date, weekly_data, ticket_reference_number)
            # st.sidebar.success("Admin data submitted successfully!")
            logging.info(f"Admin data submitted for: {email_id}")
            # Clear input fields
        st.experimental_rerun()

    if st.sidebar.button("Reset Inputs", on_click=clear_form_admin):   
         st.sidebar.success("All inputs are resets")   

def main():
    # Fetch the query parameters
    query_params = st.experimental_get_query_params()
    user_info = {
        'associate_name': query_params.get('user', [''])[0],
        'email_id': query_params.get('email', [''])[0]
    }
    role = query_params.get('role', [''])[0]

    if role == 'admin':
        display_admin_panel()
    else:
        display_dashboard(user_info, role, data)

if __name__ == '__main__':
    main()
